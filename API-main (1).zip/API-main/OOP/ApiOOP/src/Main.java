public class Main {
    public static void main(String[] args) throws Exception {
        Menu menu = new Menu(); // Creates an object of the Menu class in order to run the program
        menu.Menu(); // Calls the Menu method to run the program
    }
}
